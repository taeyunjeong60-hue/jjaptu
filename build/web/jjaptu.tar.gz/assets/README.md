<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>2026-09-19</h1>
    <h5>프로젝트 소개</h5>
    <h3>한국어 끝말잇기 게임 '끄투'에 영감받아 만든 한국어 자음, 모음 게임</h3><br>
    <h3>현재 기능</h3>
    <ul>
        <li>미구현 (입장 시스템 개발 중)</li>
    </ul>
    <h3>실행 방법</h3>
    <p>이름 작성 뒤 '입장하기' 버튼 누른 후 방 만들기 혹은 참여하여 게임 플레이</p>
    <h3>변경 사항</h3>
    <ul>
        <li>방 생성 및 기능 구현</li>
    </ul>
    <h3>다음 목표</h3>
    <ul>
        <li>게임 내부 시스템 구현</li>
        <li>방 입장 기능 추가</li>
    </ul>
    <h3>예상 실패</h3>
    <ul>
        <li>같은 닉네임의 플레이어 생성</li>
        <li>게임 시작 시 튕김</li>
    </ul>
</body>
</html>